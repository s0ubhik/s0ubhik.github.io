from os import system, name as os_name
import sys

def split2len(s, n):
    def _f(s, n):
        while s:
            yield s[:n]
            s = s[n:]
    return list(_f(s, n))

def clear():
    # check if program run in idle
    if 'idlelib.run' in sys.modules:
        for i in range(50):
            print("\n")

    elif os_name == "nt": system("cls")
    else: system("clear")


def menu(title, options, last="Back", msg="", err="", txt=""):
    options.append(last)
    while True:
        clear()

        print("+"+"-"*78+"+")
        print("|"+" "*78+"|")
        print("|"+title.center(78, " ")+"|")
        print("|"+("="*len(title)).center(78, " ")+"|")
        print("|"+" "*78+"|")
        
        if msg != "":
            for line in split2len(msg,76):
                print("| "+line.ljust(76, " ")+" |")

            print("|"+" "*78+"|")

        if txt != "":
            print("| "+txt.ljust(76, " ")+" |")
            print("|"+" "*78+"|")
            err = ""


        if err != "":
            err_msg = "ERROR: "+err
            print("| "+err_msg.ljust(76, " ")+" |")
            print("|"+" "*78+"|")
            err = ""

        c = 1
        for opt in options:
            prev = "| "+str(c)+". "
            print(prev + opt.ljust(77-len(prev)), " "+"|")
            c += 1
        
        print("|"+" "*78+"|")
        print("+"+"-"*78+"+")

        try:
            choice = int(input("Eneter your choice: "))
        except:
            err = "Invalid option :("
            continue

        if choice > len(options):
            err = "No such options"
            continue

        return choice 

def inp(prompt):
    try: text = input(prompt)
    except:
        error("Keyboard Inturrpt. Exiting....")
    return text

def error(text):
    print(text)
    exit()


def config(filename):
    try:
        fp = open(filename)
    except:
        print("config.txt not found using default config")
        return {'hostname': 'localhost', 'username': 'root', 'password': '1234', 'database': 'CS22'}
    lines = fp.readlines()
    fp.close()
    cnf = {}
    for line in lines:
        p = line.strip().split("=")
        cnf[p[0].strip()] = p[1].strip()
    return cnf
