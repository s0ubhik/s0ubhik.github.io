from ui import *
import mysql.connector as mysql
import hashlib
from datetime import datetime

# get configuration
cnf = config("config.txt")

# connect to server
print("Connecting to server... ", end='', flush=True)
try: con = mysql.Connect(host=cnf["hostname"], user=cnf["username"], password=cnf["password"], database=cnf["database"])
except Exception as e:
    print("failed")
    error("ERROR:"+str(e))
cur = con.cursor()
print("[OK]")

# check tables
sql_check_tables = "show tables"
cur.execute(sql_check_tables)
result = cur.fetchall() or ()
tables = []

for tab in result:
    tables.append(tab[0])

if "user" not in tables:
    print("Creating user table... ",end='', flush=True)
    sql_create_usr_tbl = """create table user (
        username varchar(30) primary key not null,
        password varchar(32) not null,
        fullname text(30) not null,
        balance float);"""

    cur.execute(sql_create_usr_tbl)
    print("done")

if "transaction" not in tables:
    print("Creating transaction table... ",end='', flush=True)
    sql_create_tans_tbl = """create table transaction (
        id varchar(32) primary key not null,
        amount float not null,
        time timestamp default current_timestamp,
        msg varchar(100),
        sendr varchar(30),
        recvr varchar(30),
        foreign key (sendr) references user(username),
        foreign key (recvr) references user(username));
        """

    cur.execute(sql_create_tans_tbl)
    print("done")

def md5(text):
    hash = hashlib.md5(text.encode())
    return hash.hexdigest()

def get_user(username):
    sql_get_user = f"select * from user where username = \"{username}\";"
    try: cur.execute(sql_get_user)
    except Exception as e: error("Error fetching user: ", e)
    result = cur.fetchall()
    return result

# check admin user
if get_user("admin") == []:
    print("Creating admin user... ",end='', flush=True)
    sql_admin_user = "insert into user values('admin', '"+md5('admin')+"', 'admin', -1)"
    try: cur.execute(sql_admin_user)
    except Exception as e: error("Error creating admin user: ", e)
    con.commit()
    print("done")

def main():
    txt = ""
    err = ""
    while True:
        opt = menu("Payment System", ["Login", "Create Account"], "Exit", \
            "This is a small payment system that allows multiple users one to send and   recive money", txt=txt, err=err)
        txt = ""
        err = ""
        if opt == 1:
            print("")
            print("Login")
            print("=====")
            username = inp("Enter username: ")
            password = inp("Enter password: ")
            if login(username, password):
                user_space(username)
            else:
                err = "Login Failed!"

        elif opt == 2:
            print("")
            print("Create Account")
            print("=====")
            fullname = inp("Enter fullname: ")
            username = inp("Enter username: ")
            password = inp("Enter password: ")
            if signup(fullname, username, password):
                txt = "Account created successfully :)"
            else: err = "User already exists"
        elif opt == 3:
            break

def login(username, password):
    user = get_user(username)
    if user == []: return False
    return md5(password) == user[0][1]

def signup(fullname, username, password):
    password = md5(password)
    sql_create_usr = f"insert into user values (\"{username}\",\"{password}\",\"{fullname}\",0);"
    
    try: cur.execute(sql_create_usr)
    except Exception as e:
        if "Duplicate entry" in str(e):
            return False
        else: error("Error Creating user: "+str(e))

    con.commit()
    return True

def user_space(username):
    while True:
        user = get_user(username)[0]
        bal = "unlimited" if user[3] < 0 else user[3] 

        header = ("Welcome "+user[0]).ljust(50) + "Balance: " + str(bal)
        opt = menu("Account", ["Send Money", "Transactions", "Delete Account"], msg=header)

        if opt == 1:
            print("")
            print("Send Money")
            print("==========")
            recv = inp("Enter reciptent username: ")
            
            while True:
                amnt = inp("Enter amount: ")
                try:
                    float(amnt)
                    break
                except: print("Invalid Amount :(")

            mesg = inp("Enter message(optional): ")
            if send_money(username, recv, amnt, mess=mesg):
                print("\nTransaction successfull :)\n")
            else:
                print("\nERROR: Transaction failed :(\n")
            inp("Press ENTER to get to home")

        elif opt == 2:
            trans = transaction(username)
            print()
            print("Transactions".center(80))
            print((len("Transactions")*"=").center(80))
            print()

            # show transactions
            for tran in trans:
                print("-"*80)
                sign = "+"
                if tran[4] == username:
                    man = tran[5]
                    sign = "-"
                else: man = tran[4]

                mess = tran[3][:31] + " ..." if len(tran[3]) > 34 else tran[3]

                print(sign, str(tran[1]).ljust(10), man.ljust(31), mess.ljust(34))
                print()
                print(str(tran[2]).ljust(44), tran[0])
            print("-"*80)
            print()
            inp("Press ENTER to get to home")

        elif opt == 3:
            print("Type in DELETE to corfirm that you want to delete this account")
            confirm = inp("> ")
            if confirm == "DELETE":
                delete_account(username)
                print("\nAccount deleted successfully")
                inp("Press ENTER to get to home")
                break
    
        if opt == 4: break

def send_money(sendr, recvr, amnt, mess='NULL'):
    user = get_user(sendr)[0]
    if sendr != 'admin' and user[3] < float(amnt): return False
    hash = md5(sendr + recvr + amnt + mess + str(datetime.now()))
    sql_decut_money = f"update user set balance = balance - {amnt} where username = \"{sendr}\""
    sql_send_money = f"update user set balance = balance + {amnt} where username = \"{recvr}\";"
    sql_log_trans = f"insert into transaction(id, amount, msg, sendr, recvr) values(\"{hash}\", {amnt}, \"{mess}\", \"{sendr}\",\"{recvr}\");"

    try:
        if sendr != "admin": cur.execute(sql_decut_money)
        if recvr != "admin": cur.execute(sql_send_money)
        cur.execute(sql_log_trans)
    except Exception as e:
        return False

    con.commit()
    return True

def transaction(username):
    sql_get_trans = f"select * from transaction where sendr = \"{username}\" OR recvr = \"{username}\" order by time desc;"
    try: cur.execute(sql_get_trans)
    except Exception :
        error("Error fetching transactions")
    
    return cur.fetchall()

def delete_account(username):
    sql_delete_acc = f"update user set password = \"\" where username = \"{username}\";"
    try:cur.execute(sql_delete_acc)
    except Exception :
        error("Error deleting user account")
    con.commit()
    return True

main()