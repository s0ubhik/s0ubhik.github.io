<?php
require_once("init.php");
$req = json_decode(file_get_contents('php://input'));
$id = $req->productId;

die (json_encode([crawl_product($id)]));
?>