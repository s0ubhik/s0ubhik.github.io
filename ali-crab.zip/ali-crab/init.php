<?php
use DiDom\Document;
require_once('vendor/autoload.php');
header("Content-type: application/json; charset=utf-8");

function crawl_product($id){
    $prod['id'] = $id;
    /* fetch & parse index */
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "https://www.aliexpress.com/item/$id.html");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $html_index = curl_exec($ch);
    $index = new Document($html_index);

    /* parse runParams */
    $elements = $index->find('script');
    $jsobj = strstr($elements[0]->text(), '{"tradeComponent"');
    $last_occ = strrpos($jsobj, "};"); /* remove trailing bracket */
    if ($last_occ !== false) $jsobj = substr($jsobj, 0, $last_occ);
    $params = json_decode($jsobj, true);

    /* extract info */
    $prod['name'] = $params['productInfoComponent']['subject'];
    $prod['price'] = $params['priceComponent']['origPrice']['maxPrice'];
    if (isset($params['imageComponent']['imagePathList'])) $prod['image'] = $params['imageComponent']['imagePathList'];
    $desc_url = $params['productDescComponent']['descriptionUrl'];

    /* fetch and parse description */
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $desc_url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
    $contents = curl_exec($ch);
    $desc = new Document($contents);
    foreach($desc->find('script') as $src){
        $src->remove();
    }
    $prod['desc'] = trim($desc->text());
    return $prod;
}

?>