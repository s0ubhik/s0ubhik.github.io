<?php
require_once("init.php");
use DiDom\Document;

/* fetch & parse index */
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.aliexpress.com/w/wholesale-new-products-launched.html");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$html_index = curl_exec($ch);
$index = new Document($html_index);

/* parse runParams */
$elements = $index->find('script');
$jsobj = strstr($elements[2]->text(), '{"hierarchy');
$last_occ = strrpos($jsobj, "}"); /* remove trailing bracket */
if ($last_occ !== false) $jsobj = substr($jsobj, 0, $last_occ);
$params = json_decode($jsobj, true);

/* extract product */
$top_sells = $params['data']['root']['fields']['mods']['itemList']['content'];
$top_sells = array_slice($top_sells, 0, 20); /* limit to 20 products */

/* add products */
$prods = [];
foreach($top_sells as $prd){
    $prod['name'] = $prd['title']['displayTitle'];
    $prod['price'] = $prd['prices']['salePrice']['minPrice'];
    $prod['images'] = [$prd['image']['imgUrl']];
    $prod['desc'] = "";
    $prods[] = $prod;
}

die(json_encode($prods));
?>