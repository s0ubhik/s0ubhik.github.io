<?php
require_once("init.php");
use DiDom\Document;

/* fetch & parse index */
$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://www.aliexpress.com/w/wholesale-top-selling-products.html");
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$html_index = curl_exec($ch);
$index = new Document($html_index);

/* parse runParams */
$elements = $index->find('script');
$jsobj = strstr($elements[2]->text(), '{"hierarchy');
$last_occ = strrpos($jsobj, "}"); /* remove trailing bracket */
if ($last_occ !== false) $jsobj = substr($jsobj, 0, $last_occ);
$params = json_decode($jsobj, true);

/* extract product ids */
$top_sells = $params['data']['root']['fields']['mods']['itemList']['content'];
$prod_ids = [];
foreach($top_sells as $top){ $prod_ids[] = $top['productId']; }
$prod_ids = array_slice($prod_ids, 0, 20); /* limit to 20 products */

/* fetch each product */
$prods = [];
foreach($prod_ids as $id){
    $prods[] = crawl_product($id);
}

die(json_encode($prods));
?>